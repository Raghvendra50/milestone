import pandas as pd
import psycopg2

# Load the CSV file
df = pd.read_csv('products.csv')

# Connect to PostgreSQL
conn = psycopg2.connect(
    host="localhost",
    database="ecommerce",
    user="postgres",
    password="your_password"  # Replace with your actual password
)

cur = conn.cursor()

# Insert each row into the database
for _, row in df.iterrows():
    cur.execute("""
        INSERT INTO products (name, category, price, stock, description, rating)
        VALUES (%s, %s, %s, %s, %s, %s)
    """, (row['name'], row['category'], row['price'], row['stock'], row['description'], row['rating']))

conn.commit()
cur.close()
conn.close()

print("Data loaded successfully.")
