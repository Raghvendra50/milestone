CREATE TABLE products (
    product_id SERIAL PRIMARY KEY,
    name TEXT,
    category TEXT,
    price NUMERIC(10,2),
    stock INT,
    description TEXT,
    rating NUMERIC(2,1)
);
