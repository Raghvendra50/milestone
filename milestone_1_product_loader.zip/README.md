# Milestone I: Product Loader

This repo loads product data into PostgreSQL from a CSV file.